
package app.wikimedia.artwidget.data

import kotlinx.serialization.Serializable

@Serializable
data class ArtItem(
    val title: String,
    val url: String
)
