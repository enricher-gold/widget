
package app.wikimedia.artwidget.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.RemoteViews
import app.wikimedia.artwidget.R
import app.wikimedia.artwidget.data.ArtItem
import app.wikimedia.artwidget.data.HistoryStore
import app.wikimedia.artwidget.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

object WidgetUpdater {
    const val ACTION_REFRESH = "app.wikimedia.artwidget.REFRESH"
    const val ACTION_PREVIOUS = "app.wikimedia.artwidget.PREVIOUS"

    private val imageViewIds = intArrayOf(
        R.id.img_1,R.id.img_2,R.id.img_3,R.id.img_4,
        R.id.img_5,R.id.img_6,R.id.img_7,R.id.img_8,
        R.id.img_9,R.id.img_10,R.id.img_11,R.id.img_12,
        R.id.img_13,R.id.img_14,R.id.img_15,R.id.img_16
    )

    suspend fun applyItems(context: Context, items: List<ArtItem>) {
        val rv = RemoteViews(context.packageName, R.layout.widget_random_art)
        // Wire buttons
        rv.setOnClickPendingIntent(R.id.btn_refresh, pending(context, ACTION_REFRESH))
        rv.setOnClickPendingIntent(R.id.btn_prev, pending(context, ACTION_PREVIOUS))

        val bmps = downloadBitmaps(items)
        for (i in imageViewIds.indices) {
            val id = imageViewIds[i]
            val bmp = bmps.getOrNull(i)
            if (bmp != null) {
                rv.setImageViewBitmap(id, bmp)
            } else {
                rv.setImageViewResource(id, android.R.color.transparent)
            }
        }
        val mgr = AppWidgetManager.getInstance(context)
        val cn = ComponentName(context, RandomArtWidgetProvider::class.java)
        mgr.updateAppWidget(cn, rv)
    }

    private suspend fun downloadBitmaps(items: List<ArtItem>): List<Bitmap?> = withContext(Dispatchers.IO) {
        val client = OkHttpClient()
        items.map { item ->
            try {
                val req = Request.Builder().url(item.url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use null
                    val bytes = resp.body?.bytes() ?: return@use null
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
            } catch (t: Throwable) {
                Logger.e("Bitmap download failed", t)
                null
            }
        }
    }

    private fun pending(ctx: Context, action: String): PendingIntent {
        val i = Intent(ctx, WidgetActionService::class.java).setAction(action)
        return PendingIntent.getService(ctx, action.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }
}
