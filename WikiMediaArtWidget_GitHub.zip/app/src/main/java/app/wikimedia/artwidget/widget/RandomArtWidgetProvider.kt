
package app.wikimedia.artwidget.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import app.wikimedia.artwidget.data.HistoryStore
import app.wikimedia.artwidget.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class RandomArtWidgetProvider : AppWidgetProvider() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)
        scope.launch {
            val store = HistoryStore(context)
            val current = store.currentSet()
            if (current == null) {
                // trigger a refresh action to populate
                WidgetActionService.enqueueRefresh(context)
            } else {
                WidgetUpdater.applyItems(context, current)
            }
        }
    }
}
