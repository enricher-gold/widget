
package app.wikimedia.artwidget.util

import android.util.Log

object Logger {
    private const val TAG = "ArtWidget"
    fun d(msg: String) = Log.d(TAG, msg)
    fun e(msg: String, t: Throwable? = null) = Log.e(TAG, msg, t)
}
