
package app.wikimedia.artwidget.net

import app.wikimedia.artwidget.data.ArtItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.random.Random

class WikiFetcher(
    private val client: OkHttpClient = OkHttpClient()
) {
    // Returns a list of ArtItem with direct URLs to thumbnail images.
    suspend fun fetchRandomSet(count: Int = 16, thumbWidth: Int = 400): List<ArtItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<ArtItem>()
        while (result.size < count) {
            val remaining = count - result.size
            val batch = fetchRandomBatch(minOf(remaining, 6), thumbWidth)
            result += batch
        }
        result
    }

    private fun fetchRandomBatch(count: Int, thumbWidth: Int): List<ArtItem> {
        val url = buildUrl(count, thumbWidth)
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return emptyList()
            val body = resp.body?.string() ?: return emptyList()
            val json = JSONObject(body)
            val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
            val out = mutableListOf<ArtItem>()
            val keys = pages.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val p = pages.getJSONObject(k)
                val title = p.optString("title", "Untitled")
                val ii = p.optJSONArray("imageinfo") ?: continue
                val first = ii.optJSONObject(0) ?: continue
                val thumb = first.optString("thumburl", first.optString("url", ""))
                if (thumb.isNotBlank()) out += ArtItem(title, thumb)
            }
            return out
        }
    }

    private fun buildUrl(count: Int, width: Int): String {
        // Random files from namespace 6 (File) with imageinfo and thumbnail
        // See: https://commons.wikimedia.org/w/api.php
        val params = listOf(
            "action" to "query",
            "generator" to "random",
            "grnnamespace" to "6",
            "grnlimit" to count.toString(),
            "prop" to "imageinfo",
            "iiprop" to "url",
            "iiurlwidth" to width.toString(),
            "format" to "json",
            "origin" to "*"
        )
        val q = params.joinToString("&") { it.first + "=" + URLEncoder.encode(it.second, "UTF-8") }
        return "https://commons.wikimedia.org/w/api.php?$q"
    }
}
