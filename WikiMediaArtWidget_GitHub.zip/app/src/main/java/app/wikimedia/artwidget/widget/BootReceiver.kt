
package app.wikimedia.artwidget.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        scheduleDaily(context)
    }

    companion object {
        private const val WORK_NAME = "DailyArtRefresh"
        fun scheduleDaily(context: Context) {
            val req = PeriodicWorkRequestBuilder<DailyRefreshWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(30, TimeUnit.MINUTES) // spread load a bit after boot/install
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                req
            )
        }
    }
}
