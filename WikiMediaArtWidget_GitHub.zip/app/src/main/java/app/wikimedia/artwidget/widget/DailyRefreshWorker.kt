
package app.wikimedia.artwidget.widget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import app.wikimedia.artwidget.data.HistoryStore
import app.wikimedia.artwidget.net.WikiFetcher

class DailyRefreshWorker(appContext: Context, params: WorkerParameters): CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val store = HistoryStore(applicationContext)
        val fetcher = WikiFetcher()
        val items = fetcher.fetchRandomSet()
        store.pushSet(items)
        WidgetUpdater.applyItems(applicationContext, items)
        return Result.success()
    }
}
