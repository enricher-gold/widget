
package app.wikimedia.artwidget.widget

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import app.wikimedia.artwidget.data.HistoryStore
import app.wikimedia.artwidget.net.WikiFetcher
import app.wikimedia.artwidget.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WidgetActionService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            WidgetUpdater.ACTION_REFRESH -> scope.launch { doRefresh() }
            WidgetUpdater.ACTION_PREVIOUS -> scope.launch { doPrevious() }
            else -> { /* ignore */ }
        }
        // Stop shortly after work starts
        stopSelf(startId)
        return START_NOT_STICKY
    }

    private suspend fun doRefresh() {
        val store = HistoryStore(this)
        val fetcher = WikiFetcher()
        val items = fetcher.fetchRandomSet()
        store.pushSet(items)
        WidgetUpdater.applyItems(this, items)
    }

    private suspend fun doPrevious() {
        val store = HistoryStore(this)
        val prev = store.previousSet()
        if (prev != null) {
            store.replaceCurrent(prev)
            WidgetUpdater.applyItems(this, prev)
        } else {
            // nothing to restore; do a refresh instead
            doRefresh()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun enqueueRefresh(context: Context) {
            val i = Intent(context, WidgetActionService::class.java).setAction(WidgetUpdater.ACTION_REFRESH)
            context.startService(i)
        }
    }
}
