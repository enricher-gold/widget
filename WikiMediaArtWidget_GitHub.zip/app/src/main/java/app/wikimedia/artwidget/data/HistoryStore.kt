
package app.wikimedia.artwidget.data

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.File

class HistoryStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private fun historyFile(): File = File(context.filesDir, "history.json")

    fun pushSet(items: List<ArtItem>) {
        val list = loadAll().toMutableList()
        list.add(0, items) // newest at index 0
        while (list.size > 14) list.removeLast() // keep last 14 days
        saveAll(list)
    }

    fun previousSet(): List<ArtItem>? {
        val list = loadAll()
        return if (list.size >= 2) list[1] else null
    }

    fun currentSet(): List<ArtItem>? = loadAll().firstOrNull()

    fun replaceCurrent(items: List<ArtItem>) {
        val list = loadAll().toMutableList()
        if (list.isEmpty()) list.add(items) else list[0] = items
        saveAll(list)
    }

    private fun saveAll(all: List<List<ArtItem>>) {
        historyFile().writeText(json.encodeToString(all))
    }

    private fun loadAll(): List<List<ArtItem>> {
        val f = historyFile()
        if (!f.exists()) return emptyList()
        return try { json.decodeFromString(f.readText()) } catch (_: Throwable) { emptyList() }
    }
}
