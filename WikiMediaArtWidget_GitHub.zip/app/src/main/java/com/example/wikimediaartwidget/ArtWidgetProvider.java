package com.example.wikimediaartwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/**
 * A simple AppWidgetProvider that cycles through a set of bundled art images each time
 * the widget is updated. Users can tap the "Обновить" button to advance to the next image.
 */
public class ArtWidgetProvider extends AppWidgetProvider {

    private static final String ACTION_UPDATE = "com.example.wikimediaartwidget.UPDATE_ART";

    // List of bundled drawable resources to show in the widget.
    private static final int[] IMAGE_RES_IDS = {
            R.drawable.art1,
            R.drawable.art2
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_UPDATE.equals(intent.getAction())) {
            int appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
                // If no specific widget is targeted, update all instances.
                ComponentName thisWidget = new ComponentName(context, ArtWidgetProvider.class);
                int[] ids = manager.getAppWidgetIds(thisWidget);
                for (int id : ids) {
                    updateArt(context, manager, id);
                }
            } else {
                updateArt(context, manager, appWidgetId);
            }
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // Update all widgets when requested by the system.
        for (int appWidgetId : appWidgetIds) {
            updateArt(context, appWidgetManager, appWidgetId);
        }
    }

    /**
     * Cycle to the next art image and update the widget's RemoteViews.
     */
    private static void updateArt(Context context, AppWidgetManager manager, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences("ArtWidgetPrefs", Context.MODE_PRIVATE);
        String key = "index_" + appWidgetId;
        int index = prefs.getInt(key, -1);
        index = (index + 1) % IMAGE_RES_IDS.length;
        prefs.edit().putInt(key, index).apply();

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_art);
        views.setImageViewResource(R.id.imageView, IMAGE_RES_IDS[index]);

        // Prepare the PendingIntent for the update button.
        Intent updateIntent = new Intent(context, ArtWidgetProvider.class);
        updateIntent.setAction(ACTION_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                updateIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.button_update, pendingIntent);

        manager.updateAppWidget(appWidgetId, views);
    }
}