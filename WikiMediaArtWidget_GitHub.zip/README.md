
# Wikimedia Art Widget (4x4)

Android App Widget that shows a 4×4 grid of random images from Wikimedia Commons.
- Auto-refresh daily (WorkManager)
- Manual refresh button
- “Previous set” button to restore the prior day's images
- Images are scaled **without cropping** (`centerInside`)

## Build
1. Open the folder in Android Studio (Giraffe/Koala+).
2. Sync Gradle, run on a device/emulator (API 26+).
3. Add the widget to your home screen.

## Notes
- Uses Wikimedia Commons API: `https://commons.wikimedia.org/w/api.php`.
- Keeps up to 14 historical sets in `filesDir/history.json`.
- If no previous set exists, tapping “previous” triggers a refresh.

## License
Images are from Wikimedia Commons and subject to their respective licenses.
